# 知识库交接数据包（2026-09-01 三本书完整版）

## 内容
- book1/ 《招标投标法律解读与风险防范实务（白如银）》774 页 → 850 块
- book2/ 《中华人民共和国招标投标法律法规全书（OCR）》574 页 → 3913 块
- book3/ 《政府采购、工程招标、投标与评标1200问（第3版）》552 页 → 1179 块
- cleaned_v1_markdown/：349 个政策 markdown（旧 CSV 政策链路产物）
- 每本书两个文件：
  - `*.assembled.md`      解析拼接后的完整 markdown（分块输入，人工可读）
  - `*.documents.jsonl`   向量化入库前的分块 document 数据（含 chunk_uid/chapter/chunk_index）

## 确定性（已验证 2026-09-01）
三本书的 jsonl uid 集合 == 从 assembled.md 重新分块的 uid 集合，**逐条一致**。
两条入库路径（jsonl 直入 / markdown 重分块）结果逐字段一致，仅 Milvus 主键 id 不同。

## 入库方式（任选其一）
```bash
python -m public_kb --ingest-jsonl "<book>.documents.jsonl" --mode initialize
python -m public_kb --ingest-markdown <md目录> --mode initialize   # 目录内放 *.assembled.md
```

## 前置
git pull 优化后代码（origin 分支 feat/kb-optimization-handoff）→ pip install -r requirements.txt
→ 配 .env（EMBEDDING_MODEL/BASE_URL、MILVUS_HOST/PORT、MILVUS_COLLECTION、ENABLE_MILVUS_BM25）
两端 embedding 配置与集合名一致，否则向量/uid 不一致。
