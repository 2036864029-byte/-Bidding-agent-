# 知识库交接产物说明

> 生成时间：2026-09-01。由三档路由（本地快路径 + 云端 MinerU）解析拼接后，
> 对完整 markdown 分块得到的**向量化入库前的全部数据**。

## 目录内容

每本书对应两个文件：

| 文件 | 说明 |
| --- | --- |
| `<书名>.assembled.md` | 解析拼接后的**完整 markdown**（人工可读，分块输入） |
| `<书名>.documents.jsonl` | **分块后的 Document**：每行 `{"page_content": ..., "metadata": {...}}`，含 `doc_name / chapter / chunk_index / chunk_uid` |

## 两条入库路径（任选其一，结果完全一致）

组员 `git pull` 最新代码后：

**路径 A —— 直接用 jsonl（不重新分块）：**
```bash
python -m public_kb --ingest-jsonl "<书名>.documents.jsonl" --mode initialize
```

**路径 B —— 从 markdown 重新分块入库：**
```bash
# 把 <书名>.assembled.md 放入一个目录，例如 md/
python -m public_kb --ingest-markdown md/ --mode initialize
```

## 确定性契约（为什么两边结果只有 Milvus 主键 id 不同）

- `chunk_uid` = `ck-md5(doc_name|chapter|chunk_index|text_hash)`，内容+元数据派生，**确定性**；
- 分块（SemanticChunker）、章节/序号元数据、BGE-m3 向量都是确定性纯函数；
- 唯一不可避免的差异是 **Milvus 主键 `id`**（schema `auto_id=True`，服务端自增）。
- 因此两条路径、你和组员两端入库结果**逐字段一致，仅 `id` 不同**。

## 需要对齐的配置（否则结果不一致）

1. `.env` 的 embedding 配置必须一致：`EMBEDDING_MODEL`、`EMBEDDING_BASE_URL`、`EMBEDDING_API_KEY`（同一个向量服务）；
2. 分块参数必须一致：`CHUNK_MAX_CHARS`（默认 2000）、`CHUNK_OVERLAP_CHARS`（默认 100）；
3. `collection_name`、`ENABLE_BM25`、`MILVUS_*` 保持一致（BM25 sparse 由 Milvus 服务端从 text 生成，同文本同参数 → 同向量）。

## 校验方法

入库后各导出一份 `chunk_uid` 列表对比，应 100% 相同；再抽查若干条 text/向量/元数据。

## 重新生成

路由规则或分块参数变更后重新导出：
```bash
python -m public_kb --prepare-handoff --pdf-dir <pdf目录> --out-dir <输出目录> --force
```
（不带 `--force` 时命中已存在的 `assembled.md` 缓存，只重分块，秒级完成）
